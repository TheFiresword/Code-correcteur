import java.util.*;
import java.io.*;

public class Main {
    
    public static Matrix loadMatrix(String file, int r, int c) {
        byte[] tmp =  new byte[r * c];
        byte[][] data = new byte[r][c];
        try {
            FileInputStream fos = new FileInputStream(file);
            fos.read(tmp);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(int i = 0; i < r; i++)
            for (int j = 0; j< c; j++)
                data[i][j] = tmp[i * c + j];
            return new Matrix(data);
    }
    
    // fonction r�alis�e pour simplifier exercice 9
    public static void testError(TGraph SomeGraph, Matrix baseMatrix, byte[][] error, int i){
        int rounds = 100;
        Matrix result;
        System.out.println("Mot d'erreur e"+(i+1)+":");
        byte[][] te = error;
        Matrix e = new Matrix(te);
        e.display();
        System.out.println("e"+(i+1)+" + x:");
        Matrix Errors = baseMatrix.add(e);
        Errors.display();
        System.out.println("Correction de l'erreur e"+(i+1)+" + x:");
        result = SomeGraph.decode(Errors, rounds);
        result.display();
        System.out.println("correction ?= x :"+ result.isEqualTo(baseMatrix));
    }
    
    public static void main(String[] arg){
        //exercice 2
        byte[][] tab = {{1,0,0},{0,1,0},{0,0,1}};
        Matrix m = new Matrix(tab);
        m.display();
        
        Matrix hbase = loadMatrix("data/matrix-15-20-3-4", 15, 20);
        hbase.display();

        m.display();

        byte[][] tab2 = {{0,1,0},{0,0,1},{1,0,1}};
        Matrix test = new Matrix(tab2);
        test.display();

        Matrix addMatrix = test.add(m);
        addMatrix.display();

        Matrix mulMatrix = test.multiply(m);
        mulMatrix.display();

        Matrix transpMatrix = test.transpose();
        transpMatrix.display();
        /***********************/
        // exercice 3
        hbase.display();
        hbase.addCol(1, 0);
        hbase.display();
        hbase.addRow(3, 0);
        hbase.display();
        /***********************/
        // exercice 4
        hbase = loadMatrix("data/matrix-15-20-3-4", 15, 20);
        hbase.display();
        Matrix hsys = hbase.sysTransform();
        hsys.display();
        /*********************/
        // exercice 5
        Matrix genMatrix = hsys.genG();
        genMatrix.display();
        /*********************/
        // exercice 6
        byte[][] mots = {{1,0,1,0,1}};
        test = new Matrix(mots);
        mulMatrix = test.multiply(genMatrix);
        mulMatrix.display();
        /*********************/
        // exercice 7
        
        // le code comment� ci-dessous reprend l'exemple donn� dans la deuxi�me t�che
        // (n'est pas utile pour le projet)
        // byte[][] tab3 = {{1,0,1,0},{0,1,0,1}};
        // Matrix testMat = new Matrix(tab3);
        // TGraph SomeGraph = new TGraph(testMat, 1, 2);
        // SomeGraph.display();

        TGraph SomeGraph = new TGraph(hbase, 3, 4);
        SomeGraph.display();
        /*********************/
        // exercice 8
        int rounds = 100;
        Matrix result = SomeGraph.decode(mulMatrix, rounds);
        System.out.println("Mot de code x :");
        mulMatrix.display();
        System.out.println("Correction de x :");
        result.display();
        /*********************/
        // exercice 9
        // on cr�e un tableau faisant office de liste d'erreurs
        byte[][][] error = {{{0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},{{0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},{{0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}},{{0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}}};
        for(int i = 0; i < error.length ; i++){
            testError(SomeGraph, mulMatrix, error[i],i);
            // appels successif sur la liste d'erreur
        }
        /*********************/
        // exercice 11
        
        Matrix testMatrix = loadMatrix("matrix-2048-6144-5-15", 2048, 6144);
        Matrix testsys = testMatrix.sysTransform();
        Matrix gentest = testsys.genG();
        int n = gentest.getCols();
        byte[][] word = new byte[1][n];
        for(int i=0; i < n; i++) {
        	if (i%2 == 0) {
        		word[0][i] = 1;
        	}
        	// pas n�cessaire car les valeurs sont initiatlis�es � 0
//        	else {
//        		word[0][i] = 0;
//        	}
        }
        Matrix originalword = new Matrix(word);
        TGraph testGraph = new TGraph(testMatrix, 5,15);
        //testGraph.display();
        
        // exercice 13
        n = 10*10*10*10;
        int w = 124;
        int nb_error = 0;
        int nb_echec = 0;
        for(int i = 0; i < n; i++) {
        	Matrix Generror = gentest.errGen(w);
        	Matrix y = originalword.multiply(gentest).add(Generror);
        	Matrix decode = testGraph.decode(y, 200);
        	if (!decode.isEqualTo(originalword)) {
        		if(decode.getElem(0, 1) == -1) {
        			nb_error += 1;
        		}
        		else {
        			nb_echec += 1;
        		}
        	}
        }
        int Pfail = nb_error / n *100;
        System.out.println("pourcentage echec:"+ Pfail);
        // afficher pourcentages
        /*********************/

        
    }
}
