import java.util.*;
import java.lang.Math;
import java.io.*;
public class Matrix {
    private byte[][] data = null;
    private int rows = 0, cols = 0;
    
    public Matrix(int r, int c) {
        data = new byte[r][c];
        rows = r;
        cols = c;
    }
    
    public Matrix(byte[][] tab) {
        rows = tab.length;
        cols = tab[0].length;
        data = new byte[rows][cols];
        for (int i = 0 ; i < rows ; i ++)
            for (int j = 0 ; j < cols ; j ++) 
                data[i][j] = tab[i][j];
    }
    
    public int getRows() {
        return rows;
    }
    
    public int getCols() {
        return cols;
    }
    
    public byte getElem(int i, int j) {
        return data[i][j];
    }
    
    public void setElem(int i, int j, byte b) {
        data[i][j] = b;
    }
    
    public boolean isEqualTo(Matrix m){
        if ((rows != m.rows) || (cols != m.cols))
            return false;
        for (int i = 0; i < rows; i++) 
            for (int j = 0; j < cols; j++) 
                if (data[i][j] != m.data[i][j])
                    return false;
        return true;
    }
    
    public void shiftRow(int a, int b){
        byte tmp = 0;
        for (int i = 0; i < cols; i++){
            tmp = data[a][i];
            data[a][i] = data[b][i];
            data[b][i] = tmp;
        }
    }
    
    public void shiftCol(int a, int b){
        byte tmp = 0;
        for (int i = 0; i < rows; i++){
            tmp = data[i][a];
            data[i][a] = data[i][b];
            data[i][b] = tmp;
        }
    }
     
    public void display() {
        System.out.print("[");
        for (int i = 0; i < rows; i++) {
            if (i != 0) {
                System.out.print(" ");
            }
            
            System.out.print("[");
            
            for (int j = 0; j < cols; j++) {
                System.out.printf("%d", data[i][j]);
                
                if (j != cols - 1) {
                    System.out.print(" ");
                }
            }
            
            System.out.print("]");
            
            if (i == rows - 1) {
                System.out.print("]");
            }
            
            System.out.println();
        }
        System.out.println();
    }
    
    public Matrix transpose() {
        Matrix result = new Matrix(cols, rows);
        
        for (int i = 0; i < rows; i++) 
            for (int j = 0; j < cols; j++) 
                result.data[j][i] = data[i][j];
    
        return result;
    }
    
    public Matrix add(Matrix m){
        Matrix r = new Matrix(rows,m.cols);
        
        if ((m.rows != rows) || (m.cols != cols))
            System.out.printf("Erreur d'addition\n");
        
        for (int i = 0; i < rows; i++) 
            for (int j = 0; j < cols; j++) 
                r.data[i][j] = (byte) ((data[i][j] + m.data[i][j]) % 2);
        return r;
    }
    
    public Matrix multiply(Matrix m){
        Matrix r = new Matrix(rows,m.cols);
        
        if (m.rows != cols)
            System.out.printf("Erreur de multiplication\n");
        
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < m.cols; j++) {
                r.data[i][j] = 0;
                for (int k = 0; k < cols; k++){
                    r.data[i][j] =  (byte) ((r.data[i][j] + data[i][k] * m.data[k][j]) % 2);
                }
            }
        }
        
        return r;
    }
    /* exercice 3 *********************************/
    // ajoute la ligne a et la ligne b, place le r�sultat dans b
    public void addRow(int a, int b){
        for(int i = 0; i < this.cols ; i++){
            this.data[b][i] += this.data[a][i];
            this.data[b][i] = (byte) (this.data[b][i] %2); 
        }
    }
    
    // ajoute la colonne a et la colonne b, place le r�sultat dans b
    public void addCol(int a, int b){
        for(int i = 0; i < this.rows ; i++){
            this.data[i][b] += this.data[i][a];
            this.data[i][b] = (byte) (this.data[i][b] %2);
        }
    }
/***************************************************/
    /* exercice 4 *********************************/
    // fonction renvoyant une matrice �quivalente sous forme syst�matique
    // � partir d'une matrice de forme L|R o� R est suppos�e inversible
    public Matrix sysTransform(){
        Matrix sysMatrix = new Matrix(this.data); 
        // �tape 1
        int i,i2;
        int j = sysMatrix.cols - sysMatrix.rows;
        // j donne l'indice de la colonne o� commence la matrice identit�
        for(i = 0; i < this.rows && j < this.cols ; i++){
            i2 = i;
            // on se place � la premi�re ligne o� se trouve un 1 � la colonne j
            while(i2 < this.rows && sysMatrix.data[i2][j] != 1){
                i2++;
            }
            // on �change la ligne s�lectionn�e pr�cedemment avec i2 avec la i�me ligne
            // de cette fa�on, un 1 se trouve � l'emplacement voulu de la future matrice identit�
            sysMatrix.shiftRow(i, i2);
            
            // on r�alise l'addition entre chaque ligne d'indice sup�rieur � i, o� se trouve un 1
            // avec la i�me ligne
            // pour mettre la valeur de toutes les cases d'indice de colonnes sup�rieur � la i�me � 0 
            // de cette fa�on on dispose d'un triangle inf�rieur de matrice identit� correct
            for(i2 = i+1; i2 < sysMatrix.rows ; i2++){
                if(sysMatrix.data[i2][j] == 1){
                    sysMatrix.addRow(i, i2);
                }
            }
            j++;
        }
        // �tape 2
        j = sysMatrix.cols-1;
        i = sysMatrix.rows-1;
        // on se place dans le coin inf�rieur droit de la matrice et on se d�place vers la gauche
        for(; i >= 0 && j >= 0; i--){
            i2 = i -1;
            while(i2 >= 0){ // on remonte le long de chaque colonne pour mettre les valeurs � 0
                if(sysMatrix.data[i2][j] == 1){ // en additionnant lorsque la valeur est � 1
                    sysMatrix.addRow(i, i2);
                }
                i2--;
            }
            j--;
        }
        // de cette fa�on on dispose d'une matrice �quivalente � celle d'origine
        // qui poss�de une matrice identit�, c'est donc une matrice sous forme syst�matique
        return sysMatrix;
    }
/***************************************************/
    /* exercice 5 *********************************/
    // fonction renvoyant une matrice une matrice g�n�ratrice, 
    // � partir d'une matrice de contr�le sous forme syst�matique (M | id)
 
    public Matrix genG(){
        Matrix genMatrix = new Matrix(this.cols-this.rows,this.cols);
        // la matrice g�n�ratrice a autant de lignes que le nombres de colonnes d'origine
        // en enlevant la partie de l'identit�, qui est une matrice carr�e de la taille
        // du nombre de lignes de la matrice d'origine
        for(int i = 0; i < this.rows ; i++){
            for(int j = 0 ; j  < this.cols - this.rows; j++){
            	// on remplit la matrice g�n�ratrice en inversant lignes et colonnes
            	// pour faire la transpos�e de M,
            	// prenant donc uniquement les valeurs hors identit� (j < colonne d�but identit�)
                genMatrix.data[j][i+this.cols-this.rows] = this.data[i][j];
                // il faut d�caler les valeurs car la matrice g�n�ratrice est sous forme
                // id | transpos�e de M
            }
        }
        
        for(int i = 0; i < this.cols - this.rows ; i++){
            genMatrix.data[i][i] = 1;
        } // on remplit la matrice identit�


        return genMatrix;
    }
/***************************************************/
    /* exercice 12 *********************************/
    public Matrix errGen(int w) {
    	
    	Matrix error_line = new Matrix(1,this.cols);
		Random rand = new Random();
		assert this.cols > w;
		
		// effectue la boucle le nombre d'erreurs souhait�
    	for(int i = 0; i < w ; i++) {
    		int x = (Math.abs(rand.nextInt())) % this.cols;
    		if (error_line.data[0][x] == 0){
    			// ajoute une erreur sur une case al�atoire du tableau
    			error_line.data[0][x] = 1;
    		}
    		else {
    			// si une erreur �tait d�j� pr�sente, incr�mente le nombre d'it�ration
    			w+=1;
    		}
    		
    	}
    	return error_line;
    }
    /***************************************************/

}

