public class TGraph {
	// attributs de la classe graphe
    private int n_r = 0;
    private int w_r = 0; 
    private int n_c = 0; 
    private int w_c = 0; 
    private int[][] left = null;
    private int[][] right = null;
    
    // constructeur
    public TGraph(Matrix H, int wc, int wr) {
    	// initialisation des valeurs
        this.n_r = H.getRows(); 
        this.n_c = H.getCols();
        this.w_c = wc; // nombre de 1 par colonnes
        this.w_r = wr; // nombre de 1 par ligne
        this.left = new int[n_r][w_r+1];
        this.right = new int[n_c][w_c+1];
        // initialisation de left
        int nb = 1;
        for(int i = 0 ; i < n_r ; i++){
            nb = 1;
            // pour chaque ligne i, lorsque on rencontre un 1,
            // on place l'indice de la colonne correspondante 
            // dans la premi�re colonne libre de left (>0) � la ligne i
            // nb sert � compter l'espace d�j� occup�
            for(int j = 0; j < n_c ; j++){
                if(H.getElem(i, j) == 1){
                    this.left[i][nb] = j; 
                    nb += 1;
                }
            }
        }
        // initialisation de la premi�re colonne � 0
        for(int i = 0; i < n_r; i++){
            this.left[i][0] = 0;
        }
        
        // initialisation de right
        for(int j = 0; j < n_c ; j++){
            nb = 1;
            // pour chaque colonne j, lorsque on rencontre un 1,
            // on place l'indice de la ligne correspondante 
            // dans la premi�re colonne libre de right (>0) � la ligne j
            // nb sert � compter l'espace d�j� occup�

            for(int i = 0 ; i < n_r ; i++){
                if(H.getElem(i, j) == 1){
                    this.right[j][nb] = i;
                    nb += 1;
                }
            }
        }
        // initialisation de la premi�re colonne � 0
        for(int i = 0; i < n_c; i++){
            this.right[i][0] = 0;
        }
    }
    // exercice 7
    public void display(){
        System.out.println("LEFT:");
        for(int i = 0; i < this.n_r ; i++){
            System.out.print('|');
            for(int j = 0; j < this.w_r+1 ; j++){
                System.out.print(this.left[i][j]);                
                System.out.print(" | ");

            }
            System.out.print('\n');
        }

        System.out.println("RIGHT:");
        for(int i = 0; i < this.n_c ; i++){
            System.out.print('|');
            for(int j = 0; j < this.w_c+1 ; j++){
                System.out.print(this.right[i][j] );
                System.out.print(" | ");
            }
            System.out.print('\n');
        }
    }
    
    // exercice 8
    public Matrix decode(Matrix code, int rounds){
        int i,j ;
        byte[][] x = new byte[1][code.getCols()];
        // initialisation
        // On remplit la premiere colonne de right avec le code fourni
        for(i = 0; i < this.n_c; i++){
            this.right[i][0] = code.getElem(0, i);
        }
        
        // on r�p�te l'algorithme de d�codage autant de fois que le nombre fourni en argument
        for(int c = 0; c < rounds ; c++){
        	
        	// chaque ligne de left correspondant � une equation de parit�,
        	// on op�re les equations de parit�s et on place le resultat dans la premi�re colonne
            for(i = 0; i < n_r ; i++){
                this.left[i][0] = 0;
                for(j = 1; j < w_r+1 ; j++){
                    this.left[i][0] = (this.left[i][0] + this.right[this.left[i][j]][0]) %2;
                    // on retrouve la valeur correspondante en utilisant la premi�re colonne de right
                    // et la ligne this.left[i][j] qui contient la valeur de la ligne correspondante
                }
            }
            // on regarde si une des �quations de parit� n'a pas �t� v�rifi�e
            int test = 1;
            for(i = 0; i < n_r; i++){
                if(this.left[i][0] != 0){
                    test = 0;
                    break;
                }
            }
            // si c'est le cas le code obtenu est correct
            if(test == 1){
            	// on renvoie donc la liste de valeur obtenue sous forme de matrice
                for( i = 0 ; i < this.n_c ; i++){
                    x[0][i] = (byte) this.right[i][0];
                }
                Matrix matx = new Matrix(x);
                return matx;
            }
            // sinon, on trouve la/les valeur(s) faussant le plus d'�quations de parit�
            int max = 0;
            int[] mline = new int[code.getCols()];
            int count = 0;
            int nb_val = 0;
            for( i = 0 ; i < this.n_c ; i++){
                count = 0;
                for(j = 1 ; j < w_c+1 ; j++){
                    count += this.left[this.right[i][j]][0];
                }
                // mline est un tableau conservant les num�ros de lignes
                // des valeurs faussant le plus d'equation de parit�s
                if(count == max){ // cas d'ajout d'une valeur � inverser
                    mline[nb_val] = i;
                    nb_val +=1 ;
                }
                if(count > max){ // cas d'un nouveau maximum et d'une remise � 0
                    max = count;
                    nb_val = 1;
                    mline[0] = i;
                }
            }
            // et on inverse les bits correspondant � un maximum d'erreurs
            for(i = 0 ; i < nb_val ; i++){
                this.right[mline[i]][0] = 1 - this.right[mline[i]][0];
            }
        }
        for(i = 0; i < code.getCols(); i++){
            x[0][i] = -1;
        }
        Matrix echec = new Matrix(x);
        return echec;
    }
}
